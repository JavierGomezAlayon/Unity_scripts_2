using UnityEngine;

public class Movimientomirando : MonoBehaviour
{
    public float velocidad = 3f; // velocidad de movimiento
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        // Utilizar el eje “Horizontal” para girar el objetivo y que avance siempre en la dirección hacia adelante.
        float movimiento = Input.GetAxis("Horizontal") * velocidad * Time.deltaTime;
        if (movimiento < 0f)
        {
            // miro hacia la izquierda
            transform.forward = Vector3.left;
        }
        else if (movimiento > 0f)
        {
            // miro hacia la derecha
            transform.forward = Vector3.right;
        }
        if (Input.GetAxis("Horizontal") != 0f)
        {
            transform.Translate(0f, 0f, velocidad * Time.deltaTime);
        }
        else
        {
            transform.forward = Vector3.forward;
        }
    }
}
