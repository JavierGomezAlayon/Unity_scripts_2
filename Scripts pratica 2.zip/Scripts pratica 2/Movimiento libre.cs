using UnityEngine;

public class Movimientolibre : MonoBehaviour
{
    public float velocidad = 3f; // velocidad de movimiento
    private GameObject esfera;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        esfera = GameObject.FindGameObjectWithTag("Esfera");
    }

    // Update is called once per frame
    void Update()
    {
        //recojo el input de las flechas
        float movimientoHorizontalFlechas = 0f;
        float movimientoVerticalFlechas = 0f;
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            movimientoHorizontalFlechas = -velocidad * Time.deltaTime;
        }
        if (Input.GetKey(KeyCode.RightArrow))
        {
            movimientoHorizontalFlechas = velocidad * Time.deltaTime;
        }
        if (Input.GetKey(KeyCode.UpArrow))
        {
            movimientoVerticalFlechas = velocidad * Time.deltaTime;
        }
        if (Input.GetKey(KeyCode.DownArrow))
        {
            movimientoVerticalFlechas = -velocidad * Time.deltaTime;
        }
        //muestro el resultado en la consola
        if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.RightArrow))
        {
            Debug.Log("Flecha Izquierda/Derecha: " + (movimientoHorizontalFlechas));
        }
        else
        {
            movimientoHorizontalFlechas = 0f;
        }
        if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.DownArrow))
        {
            Debug.Log("Flecha Arriba/Abajo: " + (movimientoVerticalFlechas));
        }
        else
        {
            movimientoVerticalFlechas = 0f;
        }
        //aplico el movimiento
        transform.Translate(new Vector3(movimientoHorizontalFlechas, movimientoVerticalFlechas, 0f));
        if (movimientoHorizontalFlechas != 0f || movimientoVerticalFlechas != 0f)
        {
            //miro hacia la esfera
            transform.LookAt(esfera.transform);
        }
    }
}
