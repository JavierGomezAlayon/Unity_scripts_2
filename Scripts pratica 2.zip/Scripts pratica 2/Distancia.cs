using UnityEngine;

public class Distancia : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        GameObject obj1 = GameObject.FindGameObjectWithTag("Cubo");
        GameObject obj2 = GameObject.FindGameObjectWithTag("Esfera");
        float distancia = Vector3.Distance(obj1.transform.position, obj2.transform.position);
        Debug.Log("La distancia entre el cubo y la esfera es: " + distancia);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
