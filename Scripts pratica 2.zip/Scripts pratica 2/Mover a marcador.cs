using UnityEngine;

public class Moveramarcador : MonoBehaviour
{
    public GameObject marcador; // referencia al objeto marcador
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {


    }

    // Update is called once per frame
    void Update()
    {
        // Determino el empuje para llegar al marcador
        Vector3 direccion = Input.GetAxis("Jump") * (marcador.transform.position - transform.position);
        transform.position += direccion;
    
    }
}
