using UnityEngine;

public class Movimientoesfera : MonoBehaviour
{
 public float velocidad = 3f; // velocidad de movimiento
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //recojo el input de las flechas
        float movimientoHorizontal = 0f;
        float movimientoVertical = 0f;
        if (Input.GetKey("a"))
        {
            movimientoHorizontal = -velocidad * Time.deltaTime;
        }
        if (Input.GetKey("d"))
        {
            movimientoHorizontal = velocidad * Time.deltaTime;
        }
        if (Input.GetKey("w"))
        {
            movimientoVertical = velocidad * Time.deltaTime;
        }
        if (Input.GetKey("s"))
        {
            movimientoVertical = -velocidad * Time.deltaTime;
        }
        //muestro el resultado en la consola
        if (Input.GetKey("a") || Input.GetKey("d"))
        {
            Debug.Log("Flecha Izquierda/Derecha: " + (movimientoHorizontal));
        }
        else
        {
            movimientoHorizontal = 0f;
        }
        if (Input.GetKey("w") || Input.GetKey("s"))
        {
            Debug.Log("Flecha Arriba/Abajo: " + (movimientoVertical));
        }
        else
        {
            movimientoVertical = 0f;
        }
        //aplico el movimiento
        transform.Translate(new Vector3(movimientoHorizontal, movimientoVertical, 0f));

    }
}
