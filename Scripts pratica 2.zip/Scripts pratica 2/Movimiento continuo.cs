using UnityEngine;

public class Movimientocontinuo : MonoBehaviour
{
    public Vector3 moveDirection = new Vector3(1f, 0f, 0f); // dirección de movimiento
    public float Speed = 2f; // velocidad de movimiento
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        moveDirection.Normalize(); // Normaliza la dirección al iniciar
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(moveDirection.normalized * Speed * Time.deltaTime, Space.Self);
    }
        
}
