using UnityEngine;

public class Posicion_salida : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Vector3 c = GetComponent<Transform>().position;
        Debug.Log("Posición inicial de " + gameObject.name + ": " + c);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
