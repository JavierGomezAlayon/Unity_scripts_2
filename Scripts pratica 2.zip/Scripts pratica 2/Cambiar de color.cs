using UnityEngine;

public class Cambiardecolor : MonoBehaviour
{
    Color c = new Color(1f, 0f, 0f); // Color rojo
    int contador = 0;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        GetComponent<Renderer>().material.color = c;
    }

    // Update is called once per frame
    void Update()
    {
        contador++;
        if (contador >= 120)
        {
            contador = 0;
            c.r = Random.Range(0f, 1f);
            c.g = Random.Range(0f, 1f);
            c.b = Random.Range(0f, 1f);
            GetComponent<Renderer>().material.color = c;
        }
    }
}
