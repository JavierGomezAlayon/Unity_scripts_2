using UnityEngine;

public class Operaciones_Vectores : MonoBehaviour
{
    public Vector3 vectorA;
    public Vector3 vectorB;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        // La magnitud de cada uno de ellos. 
        Debug.Log("Magnitud vector A: " + vectorA.magnitude);
        Debug.Log("Magnitud vector B: " + vectorB.magnitude);
        // El ángulo que forman
        Debug.Log("Ángulo entre A y B: " + Vector3.Angle(vectorA, vectorB));
        // La distancia entre ambos.
        Debug.Log("Distancia entre A y B: " + Vector3.Distance(vectorA, vectorB));
        // Un mensaje indicando qué vector está a una altura mayor.
        if (vectorA.y > vectorB.y)
        {
            Debug.Log("El vector A está a una altura mayor.");
        }
        else if (vectorA.y < vectorB.y)
        {
            Debug.Log("El vector B está a una altura mayor.");
        }
        else
        {
            Debug.Log("Ambos vectores están a la misma altura.");
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
